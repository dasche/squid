/*
 * Auto-Generated File. Changes will be destroyed.
 */
#include "squid.h"
#include "auth/CredentialState.h"
namespace Auth
{

const char * CredentialState_str[] = {
	"Unchecked",
	"Ok",
	"Pending",
	"Handshake",
	"Failed"
};
}; // namespace Auth
